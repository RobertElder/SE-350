// SE350 W10 RTX Project P1-(c) 

#include "rtx_inc.h"

// Prototypes
VOID rtx_dbug_out_char( CHAR c );
SINT32 rtx_dbug_outs( CHAR* s );
void process_switch(int pid); 
void proc1(void);
void proc2(void);

// C Function wrapper for TRAP #15 function to output a character
VOID rtx_dbug_out_char( CHAR c )
{
    /* Store registers */
    asm( "move.l %d0, -(%a7)" );
    asm( "move.l %d1, -(%a7)" );

    /* Load CHAR c into d1 */
    asm( "move.l 8(%a6), %d1" );

    /* Setup trap function */
    asm( "move.l #0x13, %d0" );
    asm( "trap #15" );

    /* Restore registers  */
    asm(" move.l %d1, (%a7)+" );
    asm(" move.l %d0, (%a7)+" );
}


// Print a C-style null terminated string
SINT32 rtx_dbug_outs( CHAR* s )
{
    if ( s == NULL )
    {
        return RTX_ERROR;
    }
    while ( *s != '\0' )
    {
        rtx_dbug_out_char( *s++ );
    }
    return RTX_SUCCESS;
}

void process_switch(int pid) 
{
    // Add your own code here
}



// user process proc1
// Do not make any change of this function
void proc1 () 
{
    int i =0;
    while ( 1) {
      if (i!=0 &&i%5 == 0 ) {
          rtx_dbug_outs("\n\r");
          process_switch(2); // switch to proc2
      }
      rtx_dbug_out_char('A' + i%26);
      i++;
    } 
}

// user process proc2
// Do not make any change of this function
void proc2 () 
{
    int i =0;
    while ( 1) {
      if(i!=0 && i%5==0 ) {
          rtx_dbug_outs("\n\r");
          process_switch(1); // switch to proc1
      }
      rtx_dbug_out_char('a' + i%26);
      i++;
    } 
}


// gcc expects this function to exist
int __main( void )
{
    return 0;
}

int main( void )
{
    // You can add extra code here 
    process_switch(1); // switch to proc1
    return 0;
}

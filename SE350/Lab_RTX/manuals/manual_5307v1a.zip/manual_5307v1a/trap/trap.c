#include "../rtx_inc.h"

/*
 * Prototypes
 */
VOID rtx_dbug_out_char( CHAR c );
SINT32 rtx_dbug_outs( CHAR* s );



/*
 * C Function wrapper for TRAP #15 function to output a character
 */
VOID rtx_dbug_out_char( CHAR c )
{
    /* Store registers */
    asm( "move.l %d0, -(%a7)" );
    asm( "move.l %d1, -(%a7)" );

    /* Load CHAR c into d1 */
    asm( "move.l 8(%a6), %d1" );

    /* Setup trap function */
    asm( "move.l #0x13, %d0" );
    asm( "trap #15" );

    /* Restore registers  */
    asm(" move.l (%a7)+, %d1" );
    asm(" move.l (%a7)+, %d0" );
}


/*
 * Print a C-style null terminated string
 */
SINT32 rtx_dbug_outs( CHAR* s )
{
    if ( s == NULL )
    {
        return RTX_ERROR;
    }
    while ( *s != '\0' )
    {
        rtx_dbug_out_char( *s++ );
    }
    return RTX_SUCCESS;
}



/*
 * gcc expects this function to exist
 */
int __main( void )
{
    return 0;
}


/*
 * This function is called by the assembly STUB function
 */
VOID c_trap_handler( VOID )
{
    rtx_dbug_outs( "Trap Handler!!\n\r" );
}


/*
 * Entry point, check with m68k-coff-nm
 */
int main( void )
{
    /* Load the vector table for TRAP #0 with our assembly stub
       address */
    asm( "move.l #asm_trap_entry,%d0" );
    asm( "move.l %d0,0x10000080" );

    /* Trap out three times */
    asm( "TRAP #0" );
    asm( "TRAP #0" );
    asm( "TRAP #0" );    
    return 0;
}
